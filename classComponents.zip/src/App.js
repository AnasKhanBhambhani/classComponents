import './App.css';
import UserList from './ClassComponets/UserList';




function App() {
  return (
<div className='w-full h-[100vh] bg-slate-600 flex justify-center items-center'>
<UserList/>
</div>
  );
}

export default App;
