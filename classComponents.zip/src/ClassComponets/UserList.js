import React, { Component } from 'react'
import UserCard from './UserCard'

export class UserList extends Component {
  
    render() {
        let data1 =   {
                name: 'Anas',
                email: 'anashamza457@gmail.com',
                adress: 'bahawalpur',
                phoneNo: 3466273186
            }
            let data2 =   {
                name: 'saad',
                email: 'saad457@gmail.com',
                adress: 'hasil-Por',
                phoneNo: 123456789
            }
            let data3 =     {
                name: 'asad',
                email: 'asad123@gmail.com',
                adress: 'peer-adil',
                phoneNo: 123456789
            }
        
        return (
          

<div className='flex flex-col lg:flex-row gap-2'>
            <UserCard data={data1} />
            <UserCard  data = {data2}/>
            <UserCard  data = {data3}/>
        </div>
        
          
          
        )
    }
}

export default UserList
