import React, { Component } from 'react'
export class UserCard extends Component {
    constructor() {
        super()
        this.state = {
            show: false

        }
    }
    componentDidMount(){
        //basically we use this for api call bcz of no reRendering....
        console.log("componentDidMount");
    }
    componentWillUnmount(){
        console.log("willUnmount");

    }
  
    render() {
        const {data} = this.props;
        return (
            <div className='bg-white px-12 py-12 flex h-72 w-80 flex-col items-center justify-center gap-4 mx-auto'>
                <h1 className='font-bold text-xl'>{data.name}</h1>
                <a href="#">{data.email}</a>
                {
                    this.state.show ?
                        <>
                            {console.log('Additional detail is showing now')}
                            <p>{data.adress}</p>
                            <a href="">{data.phoneNo}</a>
                        </> : console.log('Additional detail is hide now')
                }
                <button onClick={() => this.setState({show: !this.state.show })} className='bg-slate-600'>
                    {this.state.show ? 'Hide' : 'Show'} Additional Detail
                </button>
            </div>
        )
    }
}

export default UserCard
